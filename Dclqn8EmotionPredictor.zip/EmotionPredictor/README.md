# Emotion predictor

This program is a small and not so accurate model That can be used to predict the emotion of an audio clip.
I used the RAVDESS dataset to train the model and this model and an average accuracy of 70%.

After building the model I have made a program that will load the model and extract the features then ask for a recording from the user and it will then determine the emotion of the recording.